from .students import StudentRegistration
from .standard import Standards
from .school import School
from .orders import Orders
from .qrcodes import Qrcodes
from .forgotpassword import forgotpassword